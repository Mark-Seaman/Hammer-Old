/*
Copyright (c) 2015, Yahoo Inc.
Copyrights licensed under the New BSD License
See the accompanying LICENSE.txt file for terms.
*/
//#include <stdio.h>

int main(void)
{
  return 0;
}